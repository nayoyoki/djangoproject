import json
import requests
from django.contrib.auth.hashers import make_password

from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.csrf import csrf_exempt
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import serializers
from rest_framework.exceptions import ValidationError
import re
import random
from django_redis import get_redis_connection

# from api.models import UserInfo
from user.models import User


def phone_validator(value):
    if not re.match(r"^1[3-9]\d{9}$", value):
        raise ValidationError("手机格式错误")


class CodeSerializer(serializers.Serializer):
    phone = serializers.CharField(label='手机号', validators=[phone_validator])


class LoginView(APIView):
    def post(self, request, *args, **kwargs):
        print(request.data)
        return Response({"status": True})


class GetCode(APIView):
    def get(self, request, *args, **kwargs):
        ser = CodeSerializer(data=request.query_params)
        if not ser.is_valid():
            return Response({'status': False, 'message': "手机格式错误"})
        phone = ser.validated_data.get('phone')
        random_code = random.randint(1000, 9999)
        conn = get_redis_connection()
        conn.set(phone, random_code, ex=30)
        return Response({"status": True, 'message': '发送成功'})


@csrf_exempt
def get_openid(request):
    if request.method == 'POST':
        code = request.POST.get('code')
        app_id = 'wxef6fd606bd9a3cf0'
        app_secret = '6fd4645ccfcbc347da639993a1e1404b'

        # 获取 access_token
        access_token_url = 'https://api.weixin.qq.com/cgi-bin/token'
        params = {
            'grant_type': 'client_credential',
            'appid': app_id,
            'secret': app_secret
        }
        response = requests.get(access_token_url, params=params)
        data = response.json()
        access_token = data.get('access_token')

        # 获取用户手机号
        phone_number_url = f'https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={access_token}'
        phone_number_data = {
            'code': code
        }
        phone_number_response = requests.post(phone_number_url, json=phone_number_data)
        phone_number_info = phone_number_response.json()

        return JsonResponse(phone_number_info)
    else:
        return JsonResponse({'error': 'Invalid method'}, status=405)


@csrf_exempt
def get_phone(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        code = data.get('code')
        encrypted_data = data.get('encryptedData')
        iv = data.get('iv')
        openid = data.get('openid')

        # 获取 access_token
        app_id = 'wxef6fd606bd9a3cf0'
        app_secret = '6fd4645ccfcbc347da639993a1e1404b'
        token_url = f'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid={app_id}&secret={app_secret}'
        token_response = requests.get(token_url)
        token_data = token_response.json()
        access_token = token_data.get('access_token')

        # 获取手机号
        phone_url = f'https://api.weixin.qq.com/wxa/business/getuserphonenumber?access_token={access_token}'
        phone_response = requests.post(phone_url, json={'code': code})
        phone_data = phone_response.json()
        phone_number = phone_data.get('phone_info', {}).get('phoneNumber')

        # 更新数据库
        # ...

        return JsonResponse({'phoneNumber': phone_number})
    return JsonResponse({'error': 'Invalid method'}, status=405)


@csrf_exempt
def register(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        print(data)
        nickName = data.get('nickName')
        phone = data.get('phone')
        password = data.get('password')
        avatar = data.get('avatar')

        if not all([nickName, phone, password]):
            return JsonResponse({'error': '缺少必要的字段'}, status=400)

        # 验证手机号格式
        if not re.match(r'^\d{11}$', phone):
            return JsonResponse({'error': '手机号格式不正确'}, status=400)

        # 保存用户信息
        try:
            user = User(
                nickName=nickName,
                phone=phone,
                password=make_password(password),
                avatar=avatar

            )
            user.save()
            print('注册成功')
            return JsonResponse({'message': '注册成功', 'data': {"nickName": nickName, "phone": phone}})
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)

    return JsonResponse({'error': '无效的请求方法'}, status=405)


from django.contrib.auth import authenticate, login as auth_login
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json


# @csrf_exempt
# def login(request):
#     if request.method == 'POST':
#         try:
#             # 解析请求中的 JSON 数据
#             data = json.loads(request.body)
#             phone = data.get('phone')
#             password = data.get('password')
#
#             # 打印手机号和密码（注意：实际应用中请勿打印密码）
#             print('手机号：', phone)
#             print('密码：', password)
#
#             # 使用手机号和密码进行身份验证
#             user = authenticate(request, phone=phone, password=password)
#
#             if user is not None:
#                 # 如果用户存在且密码正确，进行登录
#                 auth_login(request, user)
#
#                 # 提取用户信息
#                 userInfo = {
#                     'id': user.id,
#                     'nickName': user.nickName,
#                     'phone': getattr(user, 'phone', None),
#                     'avatar': user.avatar
#                 }
#
#                 response_data = {
#                     'status': 'success',
#                     'message': '登录成功',
#                     'userInfo': userInfo
#                 }
#                 print('登录成功:', userInfo)
#             else:
#                 # 如果用户不存在或密码错误
#                 response_data = {'status': 'error', 'message': '手机号或密码错误'}
#                 print('手机号或密码错误')
#
#             return JsonResponse(response_data)
#
#         except json.JSONDecodeError:
#             # 如果请求中的 JSON 数据格式错误
#             print('无效的请求数据')
#             return JsonResponse({'status': 'error', 'message': '无效的请求数据'}, status=400)
#
#     else:
#         print('只支持 POST 请求')
#         return JsonResponse({'status': 'error', 'message': '只支持 POST 请求'}, status=405)

@csrf_exempt
def upload_avatar(request):
    if request.method == 'POST':
        try:
            # 解析请求中的数据
            phone = request.POST.get('phone')
            avatar = request.POST.get('avatar')

            # 打印请求参数
            print(f"目标电话号码: {phone}")
            print(f"上传新头像 URL: {avatar}")

            # 验证请求参数
            if not phone or not avatar:
                print("错误: 缺少电话号码或头像 URL")
                return JsonResponse({'status': 'error', 'message': '电话号码和头像 URL 是必需的'}, status=400)

            # 查找用户
            user = User.objects.filter(phone=phone).first()
            if not user:
                print(f"错误: 找不到手机号为 {phone} 的用户")
                return JsonResponse({'status': 'error', 'message': '该手机号用户未找到'}, status=404)

            # 更新头像
            user.avatar = avatar
            user.save()
            print(f"成功: 用户 {phone} 的头像已更新为 {avatar}")

            return JsonResponse({'status': 'success', 'message': '头像更新成功'}, status=200)

        except Exception as e:
            print(f"异常: {str(e)}")
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    else:
        print("错误: 请求方法无效")
        return JsonResponse({'status': 'error', 'message': '无效的请求方法'}, status=405)