from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from api import views2
# from api.views import login

urlpatterns = [
    # path('login/', views.login, name='login'),
    # path('register/', views.register, name='register'),
    path('getCode/', views2.GetCode.as_view(), name='GetCode'),
    path('getOpenid/', views2.get_openid, name='get_openid'),
    path('getPhone/', views2.get_phone, name='get_phone_number'),
    path('uploadAvatar/', views2.upload_avatar, name='upload_avatar'),
    path('oss/credential', views2.upload_avatar, name='upload_avatar'),
    path('topic/', views2.upload_avatar, name='upload_avatar'),
    path('news/', views2.upload_avatar, name='upload_avatar'),
]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

