from django.contrib.auth import authenticate, login as auth_login
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from user.models import User

@csrf_exempt
def LoginView(request):
    if request.method == 'POST':
        try:
            # 解析请求中的 JSON 数据
            data = json.loads(request.body)
            phone = data.get('phone')
            password = data.get('password')

            print('手机号：', phone)
            print('密码：', password)

            # 使用手机号和密码进行身份验证
            user = authenticate(request, phone=phone, password=password)

            if user is not None:
                # 如果用户存在且密码正确，进行登录
                auth_login(request, user)

                # 提取用户信息
                userInfo = {
                    'id': user.id,
                    'nickName': user.nickName,
                    'phone': getattr(user, 'phone', None),
                    'avatar': user.avatar
                }

                response_data = {
                    'status': 'success',
                    'message': '登录成功',
                    'userInfo': userInfo
                }
                print('登录成功:', userInfo)
            else:
                # 如果用户不存在或密码错误
                response_data = {'status': 'error', 'message': '手机号或密码错误'}
                print('手机号或密码错误')

            return JsonResponse(response_data)

        except json.JSONDecodeError:
            # 如果请求中的 JSON 数据格式错误
            print('无效的请求数据')
            return JsonResponse({'status': 'error', 'message': '无效的请求数据'}, status=400)

    else:
        print('只支持 POST 请求')
        return JsonResponse({'status': 'error', 'message': '只支持 POST 请求'}, status=405)