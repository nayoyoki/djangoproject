from django.contrib.auth import authenticate, login as auth_login
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from user.models import User
from rest_framework import serializers

@csrf_exempt
def a():
    pass
