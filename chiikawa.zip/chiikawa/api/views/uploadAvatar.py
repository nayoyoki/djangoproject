from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from user.models import User

@csrf_exempt
def UploadAvatarView(request):
    if request.method == 'POST':
        try:
            # 解析请求中的数据
            phone = request.POST.get('phone')
            avatar = request.POST.get('avatar')

            # 打印请求参数
            print(f"目标电话号码: {phone}")
            print(f"上传新头像 URL: {avatar}")

            # 验证请求参数
            if not phone or not avatar:
                print("错误: 缺少电话号码或头像 URL")
                return JsonResponse({'status': 'error', 'message': '电话号码和头像 URL 是必需的'}, status=400)

            # 查找用户
            user = User.objects.filter(phone=phone).first()
            if not user:
                print(f"错误: 找不到手机号为 {phone} 的用户")
                return JsonResponse({'status': 'error', 'message': '该手机号用户未找到'}, status=404)

            # 更新头像
            user.avatar = avatar
            user.save()
            print(f"成功: 用户 {phone} 的头像已更新为 {avatar}")

            return JsonResponse({'status': 'success', 'message': '头像更新成功'}, status=200)

        except Exception as e:
            print(f"异常: {str(e)}")
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)
    else:
        print("错误: 请求方法无效")
        return JsonResponse({'status': 'error', 'message': '无效的请求方法'}, status=405)