# import json
# from django.contrib.auth.hashers import make_password
# from django.http import JsonResponse
# from django.views.decorators.csrf import csrf_exempt
# import re
# from user.models import User
#
# @csrf_exempt
# def RegisterView(request):
#     if request.method == 'POST':
#         data = json.loads(request.body)
#         print(data)
#         nickName = data.get('nickName')
#         phone = data.get('phone')
#         password = data.get('password')
#         avatar = data.get('avatar')
#
#         if not all([nickName, phone, password]):
#             print('缺少必要的字段')
#             return JsonResponse({'error': '缺少必要的字段'}, status=400)
#
#         # 验证手机号格式
#         if not re.match(r'^\d{11}$', phone):
#             print('手机号格式不正确')
#             return JsonResponse({'error': '手机号格式不正确'}, status=400)
#
#         # 检查手机号是否已存在
#         if User.objects.filter(phone=phone).exists():
#             print('手机号已被注册')
#             return JsonResponse({'error': '手机号已被注册'}, status=400)
#
#         # 保存用户信息
#         try:
#             user = User(
#                 nickName=nickName,
#                 phone=phone,
#                 password=make_password(password),
#                 avatar=avatar
#             )
#             user.save()
#             print('注册成功')
#             return JsonResponse({'message': '注册成功', 'data': {"nickName": nickName, "phone": phone}})
#         except Exception as e:
#             return JsonResponse({'error': str(e)}, status=500)
#
#     return JsonResponse({'error': '无效的请求方法'}, status=405)
from django.http import JsonResponse
from rest_framework import serializers
from django.contrib.auth.hashers import make_password
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from user.models import User
import re

class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['nickName', 'phone', 'password', 'avatar']

    def validate_phone(self, value):
        # 验证手机号格式
        if not re.match(r'^\d{11}$', value):
            raise serializers.ValidationError("手机号格式不正确")
        return value

    def create(self, validated_data):
        # 对密码进行哈希处理
        validated_data['password'] = make_password(validated_data['password'])
        return super().create(validated_data)


@api_view(['POST'])
def RegisterView(request):
    if request.method == 'POST':
        serializer = UserSerializer(data=request.data)

        # 检查手机号是否已存在
        if User.objects.filter(phone=request.data.get('phone')).exists():
            return JsonResponse({'error': '手机号已被注册'}, status=400)

        if serializer.is_valid():
            serializer.save()
            return Response({'message': '注册成功', 'data': serializer.data}, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
