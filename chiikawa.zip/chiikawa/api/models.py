from django.db import models
from user.models import User

class Topic(models.Model):
    name = models.CharField(max_length=100, unique=True, verbose_name='话题名称')  # 话题名称
    view_count = models.PositiveIntegerField(default=0, verbose_name='浏览量')  # 话题浏览量

    def __str__(self):
        return self.name  # 返回话题名称作为模型的字符串表示


class Post(models.Model):
    title = models.CharField(max_length=200, verbose_name='标题')  # 帖子标题
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='作者')  # 作者，关联到自定义的 User 模型
    cover_image = models.CharField(max_length=255, blank=True, null=True, verbose_name='封面')  # 封面
    image = models.CharField(max_length=255, blank=True, null=True, verbose_name='图片')
    content = models.TextField(verbose_name='内容')  # 帖子内容
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE, verbose_name='话题')  # 话题，关联到 Topic 模型
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='发布时间')  # 发布时间
    updated_at = models.DateTimeField(auto_now=True, verbose_name='最后更新时间')  # 最后更新时间
    views = models.PositiveIntegerField(default=0, verbose_name='浏览量')  # 浏览量
    likes = models.PositiveIntegerField(default=0, verbose_name='获赞数')  # 获赞数
    comment_count = models.PositiveIntegerField(default=0, verbose_name='评论数')  # 评论数
    favorites = models.PositiveIntegerField(default=0, verbose_name='收藏数')  # 收藏数
    location = models.CharField(max_length=255, blank=True, null=True, verbose_name='位置')  # 位置

    def __str__(self):
        return self.title


class Comment(models.Model):
    post = models.ForeignKey(Post, related_name='comments', on_delete=models.CASCADE, verbose_name='帖子')  # 关联到 Post 模型
    author = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='作者')  # 评论作者
    content = models.TextField(verbose_name='内容')  # 评论内容
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='评论时间')  # 评论时间

    def __str__(self):
        return f'Comment by {self.author} on {self.post}'
