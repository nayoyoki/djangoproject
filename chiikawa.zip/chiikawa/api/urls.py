from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from api.views import login
from api.views import register
from api.views import uploadAvatar

urlpatterns = [
    path('login/', login.LoginView, name='login'),
    path('register/', register.RegisterView, name='register'),
    path('uploadAvatar/', uploadAvatar.UploadAvatarView, name='upload_avatar'),











]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)