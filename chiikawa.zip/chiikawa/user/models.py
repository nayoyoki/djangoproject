# myapp/models.py

from django.contrib.auth.models import AbstractBaseUser, BaseUserManager
from django.db import models


class UserManager(BaseUserManager):
    def create_user(self, phone, password=None, nickname=None, **extra_fields):
        if not phone:
            raise ValueError('请输入手机号')
        user = self.model(phone=phone, nickname=nickname, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, phone, password=None, nickname=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        return self.create_user(phone, password, nickname, **extra_fields)


class User(AbstractBaseUser):
    phone = models.CharField(max_length=11, unique=True)
    nickName = models.CharField(max_length=20, blank=True, null=True)
    password = models.CharField(max_length=128)
    avatar = models.CharField(max_length=255, blank=True, null=True)

    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)

    objects = UserManager()

    USERNAME_FIELD = 'phone'
    REQUIRED_FIELDS = []

    def __str__(self):
        return self.phone
